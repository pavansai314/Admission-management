This contains all the templates to put in the flask app.
